#记录位置管理基类
class RouterManager():
    def __init__(self):
        pass